// ===========================================
// src/models/MealPlan.ts
// ===========================================
import mongoose, { Schema, Document } from "mongoose";

export interface IMealPlan extends Document {
  title: string;
  startDate: string;
  endDate: string;
  meals: {
    day: string;
    breakfast?: string;
    lunch?: string;
    dinner?: string;
  }[];
}

const MealPlanSchema = new Schema<IMealPlan>({
  title: { type: String, required: true },
  startDate: { type: String },
  endDate: { type: String },
  meals: [
    {
      day: String,
      breakfast: String,
      lunch: String,
      dinner: String,
    },
  ],
});

export default mongoose.models.MealPlan ||
  mongoose.model<IMealPlan>("MealPlan", MealPlanSchema);
