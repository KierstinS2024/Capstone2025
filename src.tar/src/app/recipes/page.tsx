// PATH: src/app/recipes/page.tsx
"use client";

import { useState } from "react";
import { useRecipes } from "../../context/RecipeContext";
import RecipeCard from "../../components/RecipeCard";
import RecipeModal from "../../components/RecipeModal";
import Navbar from "../../components/Navbar";

export default function RecipesPage() {
  const { recipes } = useRecipes();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  return (
    <>
      <Navbar />
      <main>
        <h1>Recipes</h1>
        <div style={{ display: "grid", gap: "1rem" }}>
          {recipes.map((r) => (
            <RecipeCard
              key={r._id}
              recipe={r}
              onClick={() => setSelectedId(r._id)}
            />
          ))}
        </div>

        {selectedId && (
          <RecipeModal
            recipeId={selectedId}
            onClose={() => setSelectedId(null)}
          />
        )}
      </main>
    </>
  );
}
