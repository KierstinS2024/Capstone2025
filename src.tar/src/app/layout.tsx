// src/app/layout.tsx
import "@/app/global.css";
import Navbar from "@/components/Navbar";
import { AppProviders } from "@/context/AppProviders";

export const metadata = {
  title: "MealMate",
  description: "Meal planning made easy",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AppProviders>
          <main>{children}</main>
        </AppProviders>
      </body>
    </html>
  );
}
