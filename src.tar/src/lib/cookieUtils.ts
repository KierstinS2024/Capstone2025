// PATH: src/lib/cookieUtils.ts
import { NextResponse } from "next/server";

export function setTokenCookie(res: NextResponse, token: string) {
  res.cookies.set({
    name: "token",
    value: token,
    httpOnly: true, // client cannot read
    path: "/", // critical
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
    secure: process.env.NODE_ENV === "production",
  });
}

export function clearTokenCookie(res: NextResponse) {
  res.cookies.set({
    name: "token",
    value: "",
    httpOnly: true,
    path: "/",
    maxAge: 0,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
  });
}
