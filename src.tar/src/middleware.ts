// ===========================================
// PATH: src/middleware.ts
// ===========================================
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getUserFromRequest } from "@/lib/serverAuth";

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Protect dashboard, meal-plans, and shopping-list
  if (
    pathname.startsWith("/dashboard") ||
    pathname.startsWith("/meal-plans") ||
    pathname.startsWith("/shopping-list")
  ) {
    const user = getUserFromRequest(req);
    if (!user) return NextResponse.redirect(new URL("/login", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/meal-plans/:path*", "/shopping-list/:path*"],
};
