// PATH: src/components/RecipeDetail.tsx
"use client";

import React from "react";
import { Recipe } from "../lib/recipeApi";
import { useShoppingList } from "../context/ShoppingListContext";
import styles from "../styles/recipe-detail.module.css";

interface Props {
  recipe: Recipe;
}

export default function RecipeDetail({ recipe }: Props) {
  const { addBulk } = useShoppingList();

  const handleAddAll = () => {
    if (recipe.ingredients?.length) {
      addBulk(recipe.ingredients);
    }
  };

  return (
    <div className={styles.detail}>
      <h2>{recipe.title}</h2>

      <h3>Ingredients</h3>
      <ul className={styles.ingredientList}>
        {recipe.ingredients?.map((ingredient) => (
          <li key={ingredient}>
            <button onClick={() => addBulk([ingredient])}>+</button>{" "}
            {ingredient}
          </li>
        ))}
      </ul>

      <button onClick={handleAddAll} className={styles.addAll}>
        Add All to Shopping List
      </button>

      <h3>Instructions</h3>
      <p className={styles.instructions}>{recipe.instructions}</p>
    </div>
  );
}
