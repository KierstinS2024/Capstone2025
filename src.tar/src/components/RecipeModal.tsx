// PATH: src/components/RecipeModal.tsx
"use client";

import React, { useEffect, useState } from "react";
import { useRecipes } from "../context/RecipeContext";
import RecipeDetail from "./RecipeDetail";
import styles from "../styles/recipes.module.css";

interface Props {
  recipeId: string;
  onClose: () => void;
}

export default function RecipeModal({ recipeId, onClose }: Props) {
  const { fetchRecipe } = useRecipes();
  const [loading, setLoading] = useState(true);
  const [recipe, setRecipe] = useState<any>(null);

  useEffect(() => {
    async function load() {
      const r = await fetchRecipe(recipeId);
      setRecipe(r);
      setLoading(false);
    }
    load();
  }, [recipeId]);

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <button className={styles.closeBtn} onClick={onClose}>
          ✕
        </button>
        {loading ? (
          <p>Loading...</p>
        ) : recipe ? (
          <RecipeDetail recipe={recipe} />
        ) : (
          <p>Not found</p>
        )}
      </div>
    </div>
  );
}
