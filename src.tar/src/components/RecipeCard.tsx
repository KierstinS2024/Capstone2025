// PATH: src/components/RecipeCard.tsx
"use client";

import React from "react";
import { Recipe } from "../lib/recipeApi";
import styles from "../styles/recipes.module.css";

interface Props {
  recipe: Recipe;
  onClick: () => void;
}

export default function RecipeCard({ recipe, onClick }: Props) {
  return (
    <div className={styles.recipeCard} onClick={onClick}>
      <h3 className={styles.title}>{recipe.title}</h3>
      <p className={styles.summary}>{recipe.instructions?.slice(0, 100)}...</p>
    </div>
  );
}
