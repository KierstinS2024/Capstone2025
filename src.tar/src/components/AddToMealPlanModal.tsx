// PATH: src/components/AddToMealPlanModal.tsx
"use client";

import React, { useState } from "react";
import { useMealPlans } from "../context/MealPlanContext";
import { Recipe } from "../lib/recipeApi";
import styles from "../styles/addToMealPlanModal.module.css";

interface Props {
  recipe: Recipe;
  onClose: () => void;
}

export default function AddToMealPlanModal({ recipe, onClose }: Props) {
  const { mealPlans, updateMeal } = useMealPlans();
  const [planId, setPlanId] = useState("");
  const [date, setDate] = useState("");
  const [mealType, setMealType] = useState("breakfast");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planId || !date || !mealType) return;

    await updateMeal(planId, date, mealType as any, recipe._id);
    alert("Recipe added to meal plan.");
    onClose();
  };

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <button className={styles.closeBtn} onClick={onClose}>
          ✕
        </button>
        <h2>Add "{recipe.title}" to Meal Plan</h2>

        <form onSubmit={handleSubmit} className={styles.form}>
          <label>
            Select Meal Plan:
            <select value={planId} onChange={(e) => setPlanId(e.target.value)}>
              <option value="">-- Choose --</option>
              {mealPlans.map((p) => (
                <option key={p._id} value={p._id}>
                  {p.startDate} → {p.endDate}
                </option>
              ))}
            </select>
          </label>

          <label>
            Date:
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </label>

          <label>
            Meal:
            <select
              value={mealType}
              onChange={(e) => setMealType(e.target.value)}
            >
              <option value="breakfast">Breakfast</option>
              <option value="lunch">Lunch</option>
              <option value="dinner">Dinner</option>
            </select>
          </label>

          <button type="submit">Add to Plan</button>
        </form>
      </div>
    </div>
  );
}
