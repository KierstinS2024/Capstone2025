// PATH: src/components/MealPlanCard.tsx
"use client";

import React, { useState } from "react";
import { MealPlan } from "../lib/mealPlanApi";
import MealCard from "./MealCard";
import RecipeModal from "./RecipeModal";
import { useRecipes } from "../context/RecipeContext";
import { formatDateRange, todayISO } from "../lib/helpers";
import styles from "../styles/mealPlanCard.module.css";

interface Props {
  plan: MealPlan;
}

export default function MealPlanCard({ plan }: Props) {
  const { fetchRecipe } = useRecipes();
  const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);

  const today = todayISO();
  const mealsForToday = plan.meals[today] || {};

  async function handleMealClick(recipeId?: string) {
    if (recipeId) {
      setSelectedRecipeId(recipeId);
    } else {
      // TODO: open AddToMealPlanModal instead
      alert("Open Add Meal flow (to be implemented)");
    }
  }

  return (
    <div className={styles.planCard}>
      <h2 className={styles.dateRange}>
        {formatDateRange(plan.startDate, plan.endDate)}
      </h2>

      <div className={styles.meals}>
        <MealCard
          mealType="breakfast"
          recipe={undefined}
          onClick={() => handleMealClick(mealsForToday.breakfast)}
        />
        <MealCard
          mealType="lunch"
          recipe={undefined}
          onClick={() => handleMealClick(mealsForToday.lunch)}
        />
        <MealCard
          mealType="dinner"
          recipe={undefined}
          onClick={() => handleMealClick(mealsForToday.dinner)}
        />
      </div>

      {selectedRecipeId && (
        <RecipeModal
          recipeId={selectedRecipeId}
          onClose={() => setSelectedRecipeId(null)}
        />
      )}
    </div>
  );
}
