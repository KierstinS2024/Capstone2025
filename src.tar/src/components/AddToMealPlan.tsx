// src/components/AddToMealPlan.tsx
"use client";

import { IRecipe } from "@/types/recipe";
import { useMealPlans } from "@/context/MealPlanContext";

export default function AddToMealPlan({ recipe }: { recipe: IRecipe }) {
  const { mealPlans, addRecipeToPlan } = useMealPlans();

  return (
    <div>
      <h4>Add to Meal Plan</h4>
      {mealPlans.map((plan) => (
        <button
          key={plan._id}
          onClick={() => addRecipeToPlan(plan._id, recipe._id)}
        >
          {plan.title}
        </button>
      ))}
    </div>
  );
}
