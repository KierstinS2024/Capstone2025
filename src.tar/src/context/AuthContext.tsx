// ===========================================
// PATH: src/context/AuthContext.tsx
// ===========================================
"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import {
  login as loginApi,
  signup as signupApi,
  logout as logoutApi,
  getCurrentUser,
} from "@/lib/authHelpers";

export interface AuthUser {
  id: string;
  email: string;
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
}

// Create AuthContext
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  // Load current user on mount (if cookie exists)
  useEffect(() => {
    (async () => {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
      setLoading(false);
    })();
  }, []);

  // Login function (no router push here, let page handle navigation)
  const login = async (email: string, password: string) => {
    const loggedInUser = await loginApi(email, password);
    if (loggedInUser?.id) {
      setUser(loggedInUser); // update context
      return true;
    }
    setUser(null);
    return false;
  };

  // Signup function
  const signup = async (email: string, password: string) => {
    const newUser = await signupApi(email, password);
    if (newUser?.id) {
      setUser(newUser);
      return true;
    }
    setUser(null);
    return false;
  };

  // Logout
  const logout = async () => {
    await logoutApi();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to access AuthContext
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
