// PATH: src/context/RecipeContext.tsx
"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import {
  Recipe,
  getRecipes,
  getRecipe,
  createRecipe,
  deleteRecipe,
} from "../lib/recipeApi";
import { searchSpoonacular, getSpoonacularRecipe } from "../lib/spoonacularApi";

interface RecipeContextType {
  recipes: Recipe[];
  loading: boolean;
  fetchRecipes: () => Promise<void>;
  fetchRecipe: (id: string) => Promise<Recipe | null>;
  create: (data: Partial<Recipe>) => Promise<Recipe>;
  remove: (id: string) => Promise<void>;
  searchSpoonacular: (query: string) => Promise<any>;
  getSpoonacularRecipe: (id: string) => Promise<any>;
}

const RecipeContext = createContext<RecipeContextType | undefined>(undefined);

export function RecipeProvider({ children }: { children: React.ReactNode }) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecipes();
  }, []);

  async function fetchRecipes() {
    setLoading(true);
    try {
      const data = await getRecipes();
      setRecipes(data);
    } finally {
      setLoading(false);
    }
  }

  async function fetchRecipe(id: string) {
    try {
      return await getRecipe(id);
    } catch {
      return null;
    }
  }

  async function createNew(data: Partial<Recipe>) {
    const r = await createRecipe(data);
    await fetchRecipes();
    return r;
  }

  async function removeRecipe(id: string) {
    await deleteRecipe(id);
    await fetchRecipes();
  }

  return (
    <RecipeContext.Provider
      value={{
        recipes,
        loading,
        fetchRecipes,
        fetchRecipe,
        create: createNew,
        remove: removeRecipe,
        searchSpoonacular,
        getSpoonacularRecipe,
      }}
    >
      {children}
    </RecipeContext.Provider>
  );
}

export function useRecipes() {
  const ctx = useContext(RecipeContext);
  if (!ctx) throw new Error("useRecipes must be used within RecipeProvider");
  return ctx;
}
